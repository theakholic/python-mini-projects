# mandelbrot.py
# Lab 8
#
# Name:

# keep this import line...
from cs5png import *

# start your Lab 8 functions here:



